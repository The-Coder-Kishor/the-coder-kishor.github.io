# 💼 Hire me if you like this post

I'm available for **freelance projects** and **full-time opportunities**.

Whether you need:

- A modern, performant website
- Technical consultation
- Code review and optimization
- Or just want to chat about web development

Let's build something amazing together!

[Get in touch](mailto:astronaut@example.com)
