# I'm {author}, developer and designer.

Building premium web experiences with Astro, Svelte, and Tailwind.
Focused on performance, aesthetics, and clean code.

I am currently working on open-source tools and sharing my journey through writing.
