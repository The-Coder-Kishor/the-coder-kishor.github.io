---
title: 'Demo Post (English)'
description: 'This is a demo post in English to test cross-language linking.'
pubDate: 2026-02-02
tags: ['demo', 'i18n']
slug: 'demo-english'
lang: 'en'
translatedPosts:
  ru: 'demo-russian'
---

# Hello World

This is a demonstration of a post written in English.

It should have a link to the Russian version of this post.

## Features

- Multi-language support
- Cross-linking between translations
- Automatic flag display
