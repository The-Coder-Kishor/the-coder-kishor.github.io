---
title: 'Test Series: Introduction'
description: 'This is the first part of a test series to demonstrate the series navigation functionality.'
pubDate: 2024-03-20
tags: ['test', 'series']
series:
  id: 'test-series'
  order: 1
---

## Introduction

Welcome to the **Test Series**. This is the first post in the sequence.

The series navigation component should appear above this content, showing 3 posts in total, with this one highlighted as the current post.

### What to expect

1. **Introduction** (You are here)
2. Implementation details
3. Final thoughts

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
