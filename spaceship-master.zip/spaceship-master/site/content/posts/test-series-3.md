---
title: 'Test Series: Conclusion'
description: 'Wrapping up the test series with final thoughts.'
pubDate: 2024-03-22
tags: ['test', 'series']
series:
  id: 'test-series'
  order: 3
---

## Conclusion

This is the **final post** in the Test Series.

The navigation above should show this as the active post, with links back to Parts 1 and 2.

### Summary

We have successfully demonstrated:

1. Post linking via `series` ID.
2. Ordering via `series.order`.
3. Visual indication of the current post.

Thanks for reading!
