---
title: 'Test Series: Deep Dive'
description: 'The second part of the test series, focusing on the core content.'
pubDate: 2024-03-21
tags: ['test', 'series']
series:
  id: 'test-series'
  order: 2
---

## Deep Dive

This is the **second post** in the Test Series.

You should see:

- "Test Series: Introduction" as the previous post (link).
- "Test Series: Deep Dive" as the current post (highlighted).
- "Test Series: Conclusion" as the next post (link).

### The Content

Here is where we would discuss the main topic of the series.

```typescript
const series = {
  id: 'test-series',
  posts: 3,
};
```

Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
