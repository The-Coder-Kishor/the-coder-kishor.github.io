---
title: Пост с кастомным слагом
description: Этот пост имеет заданный вручную слаг 'custom-url'.
pubDate: 2026-02-01
tags: [test, slug]
slug: custom-url
---

У этого поста должен быть адрес `/posts/custom-url`.
