---
title: Post Title
description: Brief description of the post.
pubDate: 2026-01-31
tags: [tech]
featured: false
---

Write your content here...
