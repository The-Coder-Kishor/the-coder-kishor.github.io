---
title: 'The Future of Web Development with Astro'
event: 'AstroConf 2024'
date: 2024-05-15
type: 'talk'
link: 'https://youtube.com/example'
description: 'A deep dive into how Astro 5 and Svelte 5 are changing the way we build the web.'
lang: pl
---
