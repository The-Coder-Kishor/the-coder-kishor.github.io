---
title: 'Building Scalable Design Systems'
event: 'Modern Web Podcast'
date: 2024-03-10
type: 'podcast'
link: 'https://podcast.example.com'
description: 'Discussing the challenges of maintaining design systems in large organizations.'
---
