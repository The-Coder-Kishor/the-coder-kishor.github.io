---
title: Выступление на русском языке
event: Тестовое событие
date: 2026-02-01
type: talk
media: video
link: https://example.com/ru
description: Проверка флага в выступлениях.
lang: ru
---
