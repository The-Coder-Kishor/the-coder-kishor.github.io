---
title: Talk/Article Title
event: Conference/Website Name
date: 2026-01-31
type: talk
media: video
link: https://example.com
language: English
description: Short description of the appearance.
---
