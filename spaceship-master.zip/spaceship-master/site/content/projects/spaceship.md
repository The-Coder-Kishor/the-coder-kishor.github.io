---
title: 'Spaceship'
description: 'A premium blog template built with Astro 5, Svelte 5, and Tailwind 4.'
link: 'https://spaceship.alec.dev'
github: 'https://github.com/alec/spaceship'
tags: ['Astro', 'Svelte 5', 'Tailwind 4']
types: ['open-source']
order: 2
---
