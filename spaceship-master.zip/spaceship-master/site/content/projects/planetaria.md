---
title: 'Planetaria'
description: 'Creating the technology for sustainable commerce.'
link: 'https://planetaria.tech'
github: 'https://github.com/planetaria/core'
tags: ['Svelte', 'Node.js', 'PostgreSQL']
types: ['commercial', 'social']
order: 1
---
